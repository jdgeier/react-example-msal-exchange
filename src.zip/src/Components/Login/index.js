import * as React from 'react';
import { AzureAD, LoginType, MsalAuthProviderFactory } from 'react-aad-msal';
import { basicReduxStore } from '../../reduxStore';

class LoginComponent extends React.Component {
    constructor(props) {
        super(props);
        let redirectEnabled = sessionStorage.getItem('redirectEnabled') || true;
        this.state = {
            redirectEnabled: redirectEnabled,
        };
    }

    unauthenticatedFunction = loginFunction => {
        loginFunction();
    };

    userJustLoggedIn = receivedAccountInfo => {
        this.props.accountInfoCallback(receivedAccountInfo);
    };

    authenticatedFunction = logout => {
        return (
            <div>
            </div>
        );
    };

    config = {
        auth: {
            clientId: "33366db8-bcc5-496b-864f-efa7433c9288",
            authority: "https://login.microsoftonline.com/ecd4c5d9-c2fe-4522-afd1-f0d20755d9d7/",
        },
        cache: {
            cacheLocation: "localStorage",
            storeAuthStateInCookie: true
        }
    };

    authenticationParameters = {
        scopes: [
            'openid',
        ]
    }

    render() {
        return (

            <div>
                <AzureAD
                    provider={
                        new MsalAuthProviderFactory(
                            this.config,
                            this.authenticationParameters,
                            LoginType.Redirect,
                        )
                    }
                    unauthenticatedFunction={this.unauthenticatedFunction}
                    accountInfoCallback={this.userJustLoggedIn}
                    authenticatedFunction={this.authenticatedFunction}
                />
            </div>
        );
    }
}

export default LoginComponent;