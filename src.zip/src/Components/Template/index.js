import * as React from 'react';

class TemplateComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
            </div>
        );
    }
}

export default TemplateComponent;