import * as React from 'react';
import AppDrawer from './AppDrawer'
class ExchangeComponent extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <AppDrawer />
            </div>
        );
    }
}

export default ExchangeComponent;